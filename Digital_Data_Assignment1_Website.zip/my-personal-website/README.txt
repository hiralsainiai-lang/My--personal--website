DIGITAL DATA ASSIGNMENT 1 — PERSONAL WEBSITE

Files:
- index.html: website content
- style.css: website design and colours

BEFORE UPLOADING:
1. Open index.html in Notepad or a code editor.
2. Replace each occurrence of "Your Name" with your own name.
3. Replace the example description with your own details.
4. Save the file. Keep index.html and style.css together in the same folder.

TEST:
Double-click index.html to open it in your browser. Check the menu links and page layout.

PUBLISH:
1. Create a GitHub repository named my-personal-website.
2. Upload index.html and style.css to the repository.
3. In Vercel, import that GitHub repository and deploy it.
4. Save the public URL Vercel gives you.

AUTOMATIC UPDATE TEST:
1. Before changing anything, take a screenshot of the live website.
2. Change a small sentence in index.html, such as the introduction.
3. Save and upload/commit the updated index.html to GitHub.
4. Wait for Vercel to finish redeploying, then refresh the live URL.
5. Take an after screenshot showing the change.

REMINDER:
Use your own name and genuine details. Do not put private information such as your home address or personal phone number on a public website.
